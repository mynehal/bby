function redirect()
{
alert('allhamdulilah');
window.location.href = "https://api.whatsapp.com/send/?phone=6281284543636&text=Iyaaby, aku mau&app_absent=0";
}