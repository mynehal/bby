function redirect2()
{
alert('kenapaaaa?');
window.location.href = "https://api.whatsapp.com/send/?phone=6281284543636&text=kenapaaaaa?&app_absent=0";
}